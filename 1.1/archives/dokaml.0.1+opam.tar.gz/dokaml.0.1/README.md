# Applidok OCaml integration

OCaml integration to merge data with PDF template using [Applidok](https://go.applidok.com).

## Build

*Prerequisites:*

- Build tool OASIS (`opam install oasis`).
- Compiler `ocamlc` (tested with 4.02.x).
- Modules `core`, `async_ssl`, `cohttp.async` and `oUnit` (for testing).

```
# cp _tags.dist _tags
# oasis setup
# ./configure --enable-tests
# make test
```

[![Build Status](https://secure.travis-ci.org/applicius/dokaml.png?branch=master)](http://travis-ci.org/applicius/dokaml)

## Usage

- [API reference](http://applicius.github.io/dokaml/Dokaml.html)

**Prepare request:**

```ocaml
open Dokaml

let query : query = ("text_area", TextValue("text_val"))
                    & ("radio_area", SelectedValue("radio_value")) 
                    & ("combo_area", SelectedValue("combo_item")) 
                    & ("checkbox_area", CheckedValue) & [] in
let req : request = query @ DokCredentials("app_tok", "template_id")
```

**Call merge feature:**

Once Applidok request is prepared, it can be used with `merge_pdf'` function.

```ocaml
(* req : Dokaml.request *)
let _ = merge_pdf' req ~through:(as_file "test.pdf") in
never_returns (Scheduler.go ())
```

There `merge_pdf'` is used with handler `as_file`, which pipe successful response (PDF) to file *"test.pdf"*, and print error or success message.

> `never_returns` is required as [Async](https://realworldocaml.org/v1/en/html/concurrent-programming-with-async.html) is used to perform HTTP request concurrently.

With `'a` being type of value returned by handler in case of success and `'b` type for failure case, signature of `merge_pdf'` is:

```ocaml
request -> ('a, 'b) merge_handler -> ('a, 'b) merge_result
```

In order to easily work inside `Result.t Deferred.t`, alternative function `merge_pdf` can be used.

```ocaml
let _ = merge_pdf req ~through:(fun resp body -> printf "Success\n") in
never_returns (Scheduler.go ())
```

With `'a` being type of value return by handler, signature of function `merge_pdf` is

```ocaml
request -> Response.t -> string Pipe.Reader.t -> 'a): ('a, string) Result.t Deferred.t
```

More complete code samples are available in [source repository](https://github.com/applicius/dokaml/tree/master/samples).
