open Core.Std
open Async.Std
open Dokaml

let run ~(token:string) ~(template:string) = 
  let query : query = ("text_area", TextValue("text_val"))
                      & ("radio_area", SelectedValue("radio_value")) 
                      & ("combo_area", SelectedValue("combo_item")) 
                      & ("checkbox_area", CheckedValue) & [] in
  let req : merge_request = query @ DokCredentials(token, template) in 
  let _ = merge_pdf req ~through:(fun resp body -> 
                                  let _ = printf "Success\n" in exit 0) in
  Deferred.never ()

let () = Command.async_basic
    ~summary:"Call Applidok merge"
    Command.Spec.(
      empty
      +> flag "-token" (required string) ~doc:" Application token"
      +> flag "-template" (required string) ~doc:" Template ID"
    )
    (fun token template () -> run ~token ~template)
  |> Command.run
