open Core.Std
open Dokaml

module Dokaml_fixtures = struct
    let (success_request, success_url) = 
      let query : query = ("param1", TextValue("any_value")) & [] in
      let req = query @ DokCredentials("ignored_token", "ignored_template") 
      in (req, "https://posttestserver.com/post.php")

    let (failure_request, failure_url) = 
      let query : query = ("2_param", SelectedValue("val_b")) & [] in
      let req = query @ DokCredentials("ignored_token", "ignored_template") 
      in (req, "https://api.github.com/repos/applicius/dokaml/issues")

  end
