open Core.Std
open Async.Std
open OUnit2
open Dokaml
open Dokjson
open Dokaml_fixtures

module Dokaml_test = struct
    let parse_error_fallback ctx =
      let json = Yojson.Basic.from_string "{\"foo\": \"bar\"}" in
      let error = parse_error json "My message" in
      assert_equal ~msg:"Error must use default message" error "My message"

    let parse_error_success ctx =
      let json = Yojson.Basic.from_string "{\"exception\": \"bar\"}" in
      let error = parse_error json "My message" in
      assert_equal ~msg:"Error must use parsed message" error "bar"
    
    let handle_merge_success ctx = 
      match Thread_safe.block_on_async_exn 
              (fun _ ->
               _merge_pdf' 
                 Dokaml_fixtures.success_url 
                 Dokaml_fixtures.success_request 
                 ~through:(function 
                            | Ok(_) -> return (Ok ())
                            | Error(msg) -> return (Error (msg)))) 
      with Error(msg) 
           -> assert_failure (sprintf "Fails to perform request: %s" msg)
         | Ok(res) -> assert_equal ~msg:"Request must be successful" res ()

    let parse_auth_failure ctx =
      match parse_auth "{\"foo\":\"bar\"}"
      with Error(msg) ->
           let re = Str.regexp "Fails to parse authentication:.*Yojson\.Basic\.Util\.Type_error.*Expected string, got null.*" in
           let co = try (Str.search_forward re msg 0); true with _ -> false in
           assert_equal ~msg:"Parse error must be raise for invalid JSON"
                        co true
         | Ok(_) -> assert_failure "Should have failed to parse invalid JSON"

    let parse_auth_success ctx =
      match parse_auth "{\"token\": \"my-tok-en\"}"
      with Error(msg) ->
           assert_failure (sprintf "Should have parsed auth token: %s" msg)
         | Ok(tok) ->
            assert_equal ~msg:"Authentication token must be 'my-tok-en'"
                         tok "my-tok-en"
                                   
    let handle_merge_failure ctx = 
      match Thread_safe.block_on_async_exn 
              (fun _ ->
               _merge_pdf' 
                 Dokaml_fixtures.failure_url 
                 Dokaml_fixtures.failure_request 
                 ~through:(function 
                            | Ok(_) -> return (Ok ())
                            | Error(msg) -> return (Error (msg)))) 
      with Error(msg) 
           -> assert_equal ~msg:"Request should be forbidden"
                           msg "403 Forbidden"
         | Ok(res) -> assert_failure "Should have failed to perform request"

    let foo ctx =
      match Thread_safe.block_on_async_exn
              (fun _ -> login "demo@applicius.fr" "mdp")
      with Error(msg) -> assert_failure msg
         | Ok(res) ->
            let _ = printf "-_> %s" res in
            assert_equal ~msg:"Foo" res "Bar"

    let suite = [
        "Parse error fallback"         >:: parse_error_fallback;
        "Parse error succcess"         >:: parse_error_success;
        "Parse authentication failure" >:: parse_auth_failure;
        "Parse authentication success" >:: parse_auth_success;
        "Handle merge success"         >:: handle_merge_success;
        "Handle merge failure"         >:: handle_merge_failure
      ]

  end

let () = 
  let _ = run_test_tt_main ("Dokaml" >::: Dokaml_test.suite) 
  in ()
