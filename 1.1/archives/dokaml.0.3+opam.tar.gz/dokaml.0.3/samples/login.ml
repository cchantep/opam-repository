open Core.Std
open Async.Std
open Dokaml

let run ~(email:string) ~(password:string) =
  let _ = login email password
          >>| (fun res ->
               match res with
               | Error(msg) -> (printf "ERROR: %s\r\n" msg); exit 1
               | Ok(admtok) ->
                  (printf "SUCCESS: Admin token = %s\r\n" admtok); exit 0) 
  in Deferred.never ()

let () = Command.async_basic
    ~summary:"Call Applidok login"
    Command.Spec.(
      empty
      +> flag "-email" (required string) ~doc:" Email (login)"
      +> flag "-password" (required string) ~doc:" Password"
    )
    (fun email password () -> run ~email ~password)
  |> Command.run
