open Core.Std
open Async.Std
open Cohttp_async
open Cohttp_async.Response
open Dokjson

(** Value to be merged with a template area. [TextValue] can be merge with a text or celltext area of an Fudok template. In case of celltext, value may be truncated as merge according number of available cells in the template. [SelectedValue] can be merged with radio or combo area, and [CheckedValue] merge a checkbox area as checked. *)
type value = 
  TextValue of string 
  | SelectedValue of string 
  | CheckedValue 

(** Semantic alias for HTTP parameter prepared for a template area. *)
type parameter = string * value

type email = string
type password = string
type app_token = string
type admin_token = string
type template_id = string

(** Deferred handler result, with successful value [a] or failure [b]. *)
type ('a, 'b) handler_result = ('a, 'b) Result.t Deferred.t

(** Function that handles a result (successful or erroneous) from executing HTTP request, and return next result. *)
type ('a, 'b) response_handler = 
  (Response.t * (string Pipe.Reader.t), string) Result.t 
  -> ('a, 'b) handler_result                                        

(** Fudok credential item, application token & template ID. *)
type credentials = DokCredentials of app_token * template_id

(** Semantic alias for Fudok query. *)
type query = (string * string) list

(** For internal use only: perform a POST request *)
let _http_post (url:string) (q:query) ~(through: ('a, 'b) response_handler): ('a, 'b) handler_result =
  let uri = Uri.of_string url in
  let headers = Cohttp.Header. (* Prepare headers *)
          add_opt None "content-type" "application/x-www-form-urlencoded" in
  let params = List.map ~f:(fun (k, v) -> (k, [v])) q in
  let rawbody = Uri.encoded_of_query params in (* e.g. a=b&c=d... *)
  Client.post uri ~headers ~body:(Body.of_string rawbody) 
  >>= (fun (resp, body) -> 
       let result = match resp.status with 
         | `OK -> Ok((resp, Body.to_pipe body))
         | e -> Error(Cohttp.Code.string_of_status e) in (through result))

let login (email:email) (pass:password): (string, string) handler_result =
  let params: (string * string) list =
    ("email", email) :: ("password", pass) :: [] in
  let handler: (string, string) response_handler =
    (function Ok((resp, body)) ->
              Pipe.to_list body
              >>| (fun ls -> parse_auth (String.concat ~sep:"" ls))
            | Error(msg) -> return (Error msg))
  in _http_post "https://go.fudok.com/api/auth" params ~through:handler

(** Prepares Fudok [query] by concatenating given parameter. *)
let (&) (param:parameter) (req:query) : query = 
  let p = match param with
    | (n, TextValue(v))          -> (n, v)
    | (n, SelectedValue(v))      -> (n, v)
    | (n, _(* assume checked *)) -> (n, "on") in p :: req

(** Fudok merge request : query + credentials *)
type merge_request = { query : query }

(** Initialize an Fudok request with mandatory [credentials] (application token and template ID), and prepared [query] (parameters). *)
let (@) (query:query) (cred:credentials) : merge_request = 
  let DokCredentials(tok, tid) = cred in
  let query = ("applidok_token", tok) :: ("applidok_template", tid) :: query in
  { query }

(** For internal use only (and testing). *)
let _merge_pdf' (url:string) (req:merge_request) ~(through: ('a, 'b) response_handler): ('a, 'b) handler_result = _http_post url req.query ~through:through

(** Performs merge request, and pipe the result (either [Ok] or [Error]) pipe it [through] given function, and returns deferred pipe result. *)
let merge_pdf' (req:merge_request) ~(through: ('a, 'b) response_handler): ('a, 'b) handler_result = _merge_pdf' "https://go.fudok.com/api/merge" req ~through

(** Similar to [merge_pdf'] but handling only success case, original error details is returned if failed. *)
let merge_pdf (req:merge_request) ~(through: Response.t -> string Pipe.Reader.t -> 'a): ('a, string) handler_result = 
  merge_pdf' 
    req ~through:(function Ok((resp, body)) -> return (Ok (through resp body))
                         | Error(msg) -> return (Error msg))

(** Returns function usable with [merge_pdf'] to download PDF as file to given [path]. If request merge has failed, then [failure] function is applied on error details, otherwise [success] function is called after downloading to specified file. *)
let as_file' (path:string) ~(failure: string -> unit) ~(success: unit -> unit): (unit, unit) response_handler =
  function 
  | Ok((_, body)) -> 
     let tx: unit Deferred.t = 
       (Writer.open_file path ~append:false ~close_on_exec:true)
       >>= (fun w ->
            let out = Writer.pipe w in
            Pipe.transfer body out ~f:(fun s -> s)) in
     Deferred.map tx ~f:(fun _ -> Ok (success ()))
  | Error(msg) -> return (Error (failure msg))

(** Similar to [as_file'] with basic failure function which print {e Fails to merge: ...\n} and success function which print {e Successful merge: %s\n}. *)
let as_file (path:string): (unit, unit) response_handler = 
  as_file' path 
           ~failure:(printf "Fails to merge: %s\n") 
           ~success:(fun _ -> printf "Successful merge: %s\n" path)
