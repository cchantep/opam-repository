open Core.Std
open Async.Std
open Dokaml

let run ~(token:string) ~(template:string) ~(path:string) = 
  let query : query = ("text_area", TextValue("text_val"))
                      & ("radio_area", SelectedValue("radio_value")) 
                      & ("combo_area", SelectedValue("combo_item")) 
                      & ("checkbox_area", CheckedValue) & [] in
  let req : merge_request = query @ DokCredentials(token, template) in 
  let handler = 
    as_file' path 
             ~failure:
             (fun e -> 
              let _ = printf "Fails to download: %s\n" e in (exit 1; ()))
             ~success:
             (fun _ -> 
              let _ = printf "PDF downloaded as %s\n" path in (exit 0; ())) in
  let _ = merge_pdf' req ~through:handler in Deferred.never ()

let () = Command.async_basic
    ~summary:"Download merged PDF"
    Command.Spec.(
      empty
      +> flag "-token" (required string) ~doc:" Application token"
      +> flag "-template" (required string) ~doc:" Template ID"
      +> flag "-out" (required string) ~doc:" Output file"
    )
    (fun token template path () -> run ~token ~template ~path)
  |> Command.run
