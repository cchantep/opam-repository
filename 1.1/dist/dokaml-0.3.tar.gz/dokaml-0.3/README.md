# Fudok OCaml integration

OCaml integration to merge data with PDF template using [Fudok](https://go.fudok.com).

## Build

*Prerequisites:*

- Build tool OASIS (`opam install oasis`).
- Compiler `ocamlc` (tested with 4.02.x).
- Modules `core`, `async_ssl`, `cohttp.async` and `oUnit` (for testing).

```
cp _tags.dist _tags
oasis setup
./configure --enable-tests
make test
```

## Install

```
# opam repo add cchantep "https://raw.github.com/cchantep/opam-repository/master/1.1"
# opam update cchantep 
# opam install dokaml
```

## Usage

- [API reference](http://cchantep.github.io/dokaml/Dokaml.html)

**Merge document**

*Prepare request:*

```ocaml
open Dokaml

let query : query = ("text_area", TextValue("text_val"))
                    & ("radio_area", SelectedValue("radio_value")) 
                    & ("combo_area", SelectedValue("combo_item")) 
                    & ("checkbox_area", CheckedValue) & [] in
let req : merge_request = query @ DokCredentials("app_tok", "template_id")
```

*Call merge feature:*

Once Fudok request is prepared, it can be used with `merge_pdf'` function.

```ocaml
(* req : Dokaml.merge_request *)
let _ = merge_pdf' req ~through:(as_file "test.pdf") in
never_returns (Scheduler.go ())
```

There `merge_pdf'` is used with handler `as_file`, which pipe successful response (PDF) to file *"test.pdf"*, and print error or success message.

> `never_returns` is required as [Async](https://realworldocaml.org/v1/en/html/concurrent-programming-with-async.html) is used to perform HTTP request concurrently.

With `'a` being type of value returned by handler in case of success and `'b` type for failure case, signature of `merge_pdf'` is:

```ocaml
merge_request -> ('a, 'b) merge_handler -> ('a, 'b) merge_result
```

In order to easily work inside `Result.t Deferred.t`, alternative function `merge_pdf` can be used.

```ocaml
let _ = merge_pdf req ~through:(fun resp body -> printf "Success\n") in
never_returns (Scheduler.go ())
```

With `'a` being type of value return by handler, signature of function `merge_pdf` is

```ocaml
merge_request -> Response.t -> string Pipe.Reader.t -> 'a): ('a, string) Result.t Deferred.t
```

- *[See simple code sample](./samples/merge.ml)*
- *[See download code sample](./samples/download.ml)*

**Administration authentication**

In order to call administration features, you need to obtain the administration token by login into your Fudok account.

```ocaml
open Dokaml

let admin_token: string Result.t Deferred.t =
  login "your@ema.il" "your-password"
```

*See [code sample](./samples/login.ml)*

**Code samples**

More complete code samples are available in [source repository](https://github.com/cchantep/dokaml/tree/master/samples): 
