open Core.Std
open Result.Monad_infix

(** Parses error message from a JSON response, or using default message. *)
let parse_error (json:Yojson.Basic.json) (default:string) : string =
  let open Yojson.Basic.Util in
  try (json |> member "exception" |> to_string) with _ -> default

(** For internal use: Resolve error message from either exception or JSON. *)
let handle_exn' (e:Exn.t) (source:Yojson.Basic.json) : string =
  let ex = Exn.to_string e in
  let msg = sprintf "Fails to parse authentication: %s" ex
  in parse_error source msg
       
(** Parses JSON response from a /api/auth. *)
let parse_auth (buffer:string) : (string, string) Result.t = 
  let open Yojson.Basic.Util in
  (try Ok(Yojson.Basic.from_string buffer) with e -> Error (Exn.to_string e))
  >>= (fun json ->
       try (let tok = json |> member "token" |> to_string in Ok(tok))
       with e -> Error (handle_exn' e json))
        
