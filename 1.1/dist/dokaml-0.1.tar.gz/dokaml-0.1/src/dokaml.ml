open Core.Std
open Async.Std
open Cohttp_async
open Cohttp_async.Response

(** Value to be merged with a template area. [TextValue] can be merge with a text or celltext area of an Applidok template. In case of celltext, value may be truncated as merge according number of available cells in the template. [SelectedValue] can be merged with radio or combo area, and [CheckedValue] merge a checkbox area as checked. *)
type value = 
  TextValue of string 
  | SelectedValue of string 
  | CheckedValue 

(** Semantic alias for HTTP parameter prepared for a template area. *)
type parameter = string * value

type app_token = string
type template_id = string

(** Applidok credential item, application token & template ID. *)
type credentials = DokCredentials of app_token * template_id

(** Semantic alias for Applidok query. *)
type query = (string * string) list

(** Prepares Applidok [query] by concatenating given parameter. *)
let (&) (param:parameter) (req:query) : query = 
  let p = match param with
    | (n, TextValue(v))          -> (n, v)
    | (n, SelectedValue(v))      -> (n, v)
    | (n, _(* assume checked *)) -> (n, "on") in p :: req

(** Applidok request : query + credentials *)
type request = { query : query }

(** Initialize an Applidok request with mandatory [credentials] (application token and template ID), and prepared [query] (parameters). *)
let (@) (query:query) (cred:credentials) : request = 
  let DokCredentials(tok, tid) = cred in
  let query = ("applidok_token", tok) :: ("applidok_template", tid) :: query in
  { query }

(** Deferred merge result, with successful value [a] or failure [b]. *)
type ('a, 'b) merge_result = ('a, 'b) Result.t Deferred.t

(** Function that handles a result (successful or erroneous) from executing HTTP merge request, and return next result. *)
type ('a, 'b) merge_handler = 
  (Response.t * (string Pipe.Reader.t), string) Result.t 
  -> ('a, 'b) merge_result

(** For internal use only (and testing). *)
let _merge_pdf' (url:string) (req:request) ~(through: ('a, 'b) merge_handler): ('a, 'b) merge_result = 
  let uri = Uri.of_string url in
  let headers = Cohttp.Header. (* Prepare headers *)
          add_opt None "content-type" "application/x-www-form-urlencoded" in
  let params = List.map ~f:(fun (k, v) -> (k, [v])) req.query in
  let rawbody = Uri.encoded_of_query params in (* e.g. a=b&c=d... *)
  Client.post uri ~headers ~body:(Body.of_string rawbody) 
  >>= (fun (resp, body) -> 
       let result = match resp.status with 
         | `OK -> Ok((resp, Body.to_pipe body))
         | e -> Error(Cohttp.Code.string_of_status e) in (through result))

(** Performs merge request, and pipe the result (either [Ok] or [Error]) pipe it [through] given function, and returns deferred pipe result. *)
let merge_pdf' (req:request) ~(through: ('a, 'b) merge_handler): ('a, 'b) merge_result = _merge_pdf' "https://go.applidok.com/api/merge" req ~through

(** Similar to [merge_pdf'] but handling only success case, original error details is returned if failed. *)
let merge_pdf (req:request) ~(through: Response.t -> string Pipe.Reader.t -> 'a): ('a, string) Result.t Deferred.t = 
  merge_pdf' 
    req ~through:(function Ok((resp, body)) -> return (Ok (through resp body))
                         | Error(msg) -> return (Error msg))

(** Returns function usable with [merge_pdf'] to download PDF as file to given [path]. If request merge has failed, then [failure] function is applied on error details, otherwise [success] function is called after downloading to specified file. *)
let as_file' (path:string) ~(failure: string -> unit) ~(success: unit -> unit): (unit, unit) merge_handler =
  function 
  | Ok((_, body)) -> 
     let tx: unit Deferred.t = 
       (Writer.open_file path ~append:false ~close_on_exec:true)
       >>= (fun w ->
            let out = Writer.pipe w in
            Pipe.transfer body out ~f:(fun s -> s)) in
     Deferred.map tx ~f:(fun _ -> Ok (success ()))
  | Error(msg) -> return (Error (failure msg))

(** Similar to [as_file'] with basic failure function which print {e Fails to merge: ...\n} and success function which print {e Successful merge: %s\n}. *)
let as_file (path:string): (unit, unit) merge_handler = 
  as_file' path 
           ~failure:(printf "Fails to merge: %s\n") 
           ~success:(fun _ -> printf "Successful merge: %s\n" path)
