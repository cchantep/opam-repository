open Core.Std
open Async.Std
open OUnit2
open Dokaml
open Dokaml_fixtures

module Dokaml_test = struct
    let handle_success ctx = 
      match Thread_safe.block_on_async_exn 
        (fun _ ->
         _merge_pdf' 
           Dokaml_fixtures.success_url 
           Dokaml_fixtures.success_request 
           ~through:(function 
                      | Ok(_) -> return (Ok ())
                      | Error(msg) -> return (Error (msg)))) 
      with Error(msg) 
           -> assert_failure (sprintf "Fails to perform request: %s" msg)
         | Ok(res) -> assert_equal ~msg:"Request must be successful" res ()
                           
    let handle_failure ctx = 
      match Thread_safe.block_on_async_exn 
        (fun _ ->
         _merge_pdf' 
           Dokaml_fixtures.failure_url 
           Dokaml_fixtures.failure_request 
           ~through:(function 
                      | Ok(_) -> return (Ok ())
                      | Error(msg) -> return (Error (msg)))) 
      with Error(msg) 
           -> assert_equal ~msg:"Request should be forbidden"
                           msg "403 Forbidden"
         | Ok(res) -> assert_failure "Should have failed to perform request"

    let suite = [
        "Handle success"  >:: handle_success;
        "Handle failure"  >:: handle_failure
      ]

  end

let () = 
  let _ = run_test_tt_main ("Dokaml" >::: Dokaml_test.suite) 
  in ()
